import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tw-post',
  templateUrl: './tw-post.component.html',
  styleUrls: ['./tw-post.component.css']
})
export class TwPostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
