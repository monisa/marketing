#!/usr/bin/python

from attic import *
